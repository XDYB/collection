1. 产品业务上，我要参与讨论，评审各个需求，保证简单易用
2. 技术上
  第一，设计整体框架，搭建开发测试环境，CI/CD 流程，尽量让大家关注于业务开发
  第二，制定编码规范，研发规范，开发文档等，人多了无规矩就乱套了
  第三，评审技术方案设计，保证设计的合理性，可扩展性，还要严格审核每个 pull request ，做 code review 。认真做好每一次，否则很容易发生“破窗效应”
3. 项目管理上，现在有很多任务并行开展，要有条不紊，不冲突，尽量不延期
4. 团队建设上，我要招聘考核新成员，做新成员，制定团队纪律和规范，定期和成员 1-1 沟通，保证合作没有隔阂
5. 未来规划上，要考虑未来 1 年要做的事情
杭州：字节、阿里、网易、zoom、吉利、得物、杭州银行、哈罗、华为、腾讯、有赞、同花顺、顺丰、BitMart
上海：PDD、虾皮、小红书、PayPal、特斯拉、百度、美团、哔哩哔哩、蔚来




1. 结党营私
第一梯队 字节虾皮阿里
第二梯队 美团
第三梯队 b站，网易，小红书，pdd，shopline
https://hr.163.com/user.html/application

上一战的总纲，是君子厚积薄发，资源用尽后必然动作变形；

这一战的总纲，是君子审时度势，别在对手的英雄景点一条道走到黑。

永远打造自己的优势项目，打造自己的英雄景点，别总在老摔跟头的地方跟自己较劲。

不断的重复那些胜利的、幸运的符号和资产是一种智慧。

当年救过你的命，此后还会救你的命；当年就百般阻挠困苦，此后只会比从前磨难更多。

宇文邕是宇文毓执政这两年的特殊发现，所有的朝廷大事多与这兄弟商量，这孩子城府极深，不问他从来不说，但只要说了永远都在点上。（鲁公幼有器质，特为世宗所亲爱，朝廷大事，多与之参议；性深沉，有远识，非因顾问，终不辄言。世宗每叹曰：夫人不言，言必有中）


scss各种问题
npm包版本问题
  在package.json中引入依赖包进行管理的时候，依赖的版本号前面带有~和^。
  这两个符号是什么意思呢？
  “~3.4.5” 表示 安装3.4.x的最新版本，可以是3.4.6，3.4.7， ......3.4.99，但是不安装3.5.x的版本，也就是安装时不大于主版本号和次版本号。
  “^3.4.5” 表示 安装3.4.5以上的版本，可以是3.4.x，3.5.x，3.6.x，3.x.x，但是不安装4.x.x的版本，也就是安装时不大于主版本号
npm ci

下午5点

{
  test: /\.less$/i,
  use: [
    {
      loader: 'style-loader', // 从 JS 中创建样式节点
    },
    {
      loader: 'css-loader', // 转化 CSS 为 CommonJS
    },
    {
      loader: 'less-loader', // 编译 Less 为 CSS
    },
  ],
}



ssh luoxupan@gzrelay.sys.xiaojukeji.com -p 35000
dssh ibt-ibddp-node-pre-sf-e828a-0.docker.us01
sudo -iu xiaoju
dssh ibt-fe-static-pre-000.docker.us01

堡垒机
ssh luoxupan@gzrelay.sys.xiaojukeji.com -p 35000

登入gatway堡垒机
1. 在~/.ssh/config下加下这个配置
  Host didi_jump
    HostName xgrelay.sys.xiaojukeji.com
    User luoxupan
    Port 35000
2. 之后  ssh didi_jump
3. 上odin查机器ip
  http://odin.xiaojukeji.com/#/tree/machine/operate?category=cluster&isLeaf=true&ns=us01.static.fe.ibt.didi.com
4. dssh ip
5. 查日志
  cd /home/xiaoju/applogs
  tail -f ./all.log
  tail -f ./all.log | grep zhangkeyang


================================
Starship支持注册车辆信息
1. 用户无权限组件开发
2. 车辆注册工具首页表格开发
3. 车辆上传表格分页器开发
4. 车辆信息上传创建弹窗表单开发
5. 车辆注册任务详情页面 头部基础信息卡片开发
6. 车辆注册任务详情页面 表格开发
7. 车辆信息编辑页面基础信息组件
8. 车辆信息编辑页面上传文件组件开发
9. 车辆注册任务编辑页面 可编辑表格开发
10. 可编辑表格 字段说明弹窗开发
================================
Starship支持注册车辆信息
1. 文件上传错误弹窗提醒组件开发
2. 文件上传组件开发
3. 文件上传组件进度条开发
4. 车辆上传编辑表单cancel后二次确认弹窗
5. 审核失败文件下载
6. 附件上传组件状态控制
7. 任务提交和保存业务开发
Starship支持查看及下载车头&司机维度收入报表
1. 写技术评审文档
================================
Starship支持注册车辆信息
1. 文件上传改成自定义base64
2. 联调、测试
Starship支持查看及下载车头&司机维度收入报表
1. 报表搜索栏开发
2. 报表表格开发
3. 报表详情开发
4. 报表弹窗和下载开发
5. 时间组件时间可选限制
6. 使用权限控制开发
================================
Starship支持查看及下载车头&司机维度收入报表
1. 时间区间校验
2. 下载详情流水代码
3. 联调、测试、UI走查还原
================================
Starship支持查看及下载车头&司机维度收入报表
1. 翻译
2. 首页搜索框加回车交互
3. 首页取消按钮干掉，搜索输入框加X
4. 回车或者结果页取消都把其它搜索条件删除
5. 车头详情弹窗关闭后条件还原
拉新转化看板
1. 新增两个车头、司机页面，调整UI
2. 语言下掉南非和俄罗斯，国家下掉俄罗斯
================================
拉新转化看板
1. 看板类型参数控制
2. 联调、UI还原
3. 柱状图增加tooltip逻辑
================================
1. 自定义模板，当有深层对象时，用户输入数据卡顿优化
2. 模板样式和布局更改以适应深层次对象
3. 模板对象数组组件 操作按钮组由之前的代码控制hover显示改成全部显示，避免不必要的组件代码执行渲染
1. 搜索工具漏斗看板及司机状态分类逻辑修改
================================
拉新转化看板
1. 时间圈选列表跳转控制
2. 漏斗时间选择器默认时间控制
3. 修改字体和字体文件

Starship区分车头类型
1. 翻译和图标逻辑更改
2. 样式调整，表格开发
3. 表格增加列，表单顶部模块开发
4. 顶部搜索栏开发



0.3
  1. 技术评审，确认页面是否接入数易 拉齐
  2. 经过调研数易能力暂不支持此次需求柱状图能力 所以自己开发
    1. 这次筛选器比较复杂，有季度，年，月，日历筛选，数易暂时不支持。
    2. 柱状图需要表达相邻 柱状图转化率 这是个比较定制画的开发，数易不支持
    3. 数易柱状图不支持改颜色，半个页面颜色也不搭

今天周五空闲了点，下午找starship的PM和北斗后端明炜聊了下，也回顾了下最近所做的一些事情算是做个总结
starship
1. 和PM聊完后，starship今年是堆功能为主，和响应业务方的需求
北斗投放（说一下最近提效的几个事情）
1. 功能放量能力（苗蕊开发）
2. 投放配置批量更改（苗蕊开发）
3. 模板优化，主要针对深层次对象表单优化，和视觉使用优化，现在卡顿有了明显的改观，但是模板非常大也是有点卡的（序盼）
4. 和明炜聊了下，super app首页接下来可能会在北斗在开个入口模块单独支持super app首页业务


接入数易plan计划。（如果数易不支持或者中间出现风险，我们前端需要给出的计划）
1. 我们先上，i18n等数易支持后我们再配置
2. 我们自己写


对于宇舟数据那边
1. 无时区概念，宇舟会算好国家对应首都时区的数据（支持联动）
2. 有时区概念宇舟会算好每小时数据存储为北京时区。（需手动编辑）




















北斗投放模板性能问题
1. 实验中心功能配置，实验分流过多、模板过大时模板加载慢
  1. 模板加载中https://dpubstatic.udache.com/static/dpubimg/mWkhoySgAk/temp01.png
  2. 模板加载后https://dpubstatic.udache.com/static/dpubimg/zKLbTpUX1j/temp02.png
  原因：
2. 配置中心功能配置，模板过大时动态表单输入数据反应慢
3. 实验中心模板数据保存 页面卡死


1. 入口
2. 任务中心
3. 查看任务
4. 新建任务
5. 信息录入	






TODO:
1. 车辆注册技术方案书写-前端实现重点方案
2. 投放模板性能问题--找出问题所在的地方
  1. 实验配置页面加载慢
  2. 详情页面-模板加载已有数据慢
3. 投放业务串讲PPT
4. 填写望岳人力投入





Promise.resolve('33')
.then((res) => new Promise((resolve) => resolve(res)))
.then((e) => e)
.then((e) => console.log(e))



TODO:
fleet app接入push需求 需要写技术粗评wiki
老板们，fleet这边暂定周四上午11:00～12:00进行技术粗评哈 辛苦大家参加一下@所有人
http://wiki.intra.xiaojukeji.com/pages/viewpage.action?pageId=732098059




  





本地启动开发修改点：
1. platform/basic/config/webpack.dev.ts
  2. disableHostCheck: true,
2. platform/basic/src/api/instance.ts
  1. const baseURL = 'http://d-code-pre.intra.didiglobal.com/no-code'
  2. withCredentials: true,








UI组件库Tip: 需要考虑的点
1. 公共组件技术选型、ts、开发联调方案-storybook 支持字段参数配置
2. 公共组件用户使用文档自动生成-storybook+注释/自定义文档 自动生成文档页面
3. webpack + ts-loader打包，tsconfig.json 配置支持
4. 多语言支持方案
5. 发包方案 需要支持测试版npm包-npm测试包发到gift-测试包原理
  https://docs.npmjs.com/cli/v7/commands/npm-install#description
6. 正式版本npm包
7. 当组件量太大如何解决编译速度问题

9. 介绍 package.json 里面各个字段的含义
  main、files
  devDependencies和dependencies的区别
  当作为一个npm包的时候dependencies的依赖也会被下载到node_modules中
  8. 安全：通过代码配置避免把代码发到 www.npmjs.com 导致代码泄露
  "publishConfig": {
    "registry": "http://npm.intra.xiaojukeji.com"
  },


function fetchComp() {
  var thenable = new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(2)
    })
  })
  var pending = {};
  pending._result = thenable;
  
  thenable.then((res) => {
    console.log('error:_result', res)
    pending._result = res;
  })
  throw pending._result;
}

try {
  fetchComp();
} catch (error) {
  console.log('error:', error)
  error.then((data) => {
    console.log('error:data', data)
  })
}




HashRouter和BrowserRouter
hash模式和history区别。

HashHistory优缺点：
a.通过URL的hash来模拟一个完整的URL，URL改变页面不会重载。
b.hash路由后面有“#”号，可以理解为URL锚点，#后面的url发生改变不会发起http请求。
c.可以通过改变锚点值来渲染页面中的不同DOM
d.可以通过onhashchange来监听hash值的改变

HTML5History优缺点：
a.利用HTML5History的pushState和replaceState特性来响应当前页面的更新（IE9不支持，VueRouter默认会转为hash模式，如果强制使用history，则配置fallback:false）。
b.pushState和replaceState参数中的URL可以为任一同源URL（可以是不同的HTML），而hash只能是同一文档。
c.pushState和replaceState参数中state可以为任意js对象，而hash只能为短字符串。
d.需要后端支持，处理404错误。
e.通过onpopstate来监听路由的改变。

八股文虽然很多没什么用，但是该背还得背
不管你写Vue的还是React的，很容易被问到两者区别，建议从多个角度去聊，比如框架特性、生态、开发体验、社区评价、性能、源码等多个角度聊
有亮点的项目最好多准备几个，最好是不同类型的，比如业务的、偏中后端的、组件库的、工程化的和新兴技术的，根据自己擅长的内容最起码准备两三个，有的面试官就是想看你都做过哪些有难度的事情，一招鲜这时候就不好用了
对不同的角色的面试官问的问题，要在不同的角度回答，比如同样问你有没有处理过兼容性问题，对前面的面试官，就可以回答遇到过的不兼容的场景和解决细节，遇到后面leader的面试就可以更多地从如何高效验证排查兼容性问题这个角度回答，注意场景
最后一般面试官都会给提问题的时间，我个人一般是问业务内容、技术栈、团队规模或者未来业务和技术上发展方向，到后面的面试官我会问一下这位面试官在这个团队中的角色，根据他的角色结合他对上面几个问题的表述可以初步判断出这个团队是边缘的，还是核心的，还是单纯是个画大饼的






接雨水、鸡蛋落地。
---
Promise 详细聊一下，可以解决哪些问题
---
p 成功的会如何走，如果 p 失败了进入 b 之后，b 中又失败了是否会继续执行后面的 c 或 d
p.then(a, b).then(c).catch(d);

Promise.resolve(1).then((v) => {
  console.log('then1:', v);
}, (error) => {
  console.log('error:', error);
}).then(() => {
  console.log('then2');
}).catch((reason) => {
  console.log('reason:', reason);
})
---
下面这个 class 的四个属性分别属于这个 class 的什么，fn 和 f 有什么区别
class A {
  static a = 1;
  b = 2;
  fn() {}
  f = () => {};
}
https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Classes/Public_class_fields#%E5%85%AC%E6%9C%89%E5%AE%9E%E4%BE%8B%E5%AD%97%E6%AE%B5
https://www.babeljs.cn/repl#?browsers=&build=&builtIns=usage&corejs=3.6&spec=false&loose=false&code_lz=MYGwhgzhAECC0G8BQ1oQC5nQS2NM0AvNAIwDcK0ARkdAEwWoBmAdgBQCUiAvpU7ZyIA-HhW5A&debug=false&forceAllTransforms=false&shippedProposals=false&circleciRepo=&evaluate=false&fileSize=false&timeTravel=false&sourceType=script&lineWrap=true&presets=env%2Cstage-0&prettier=true&targets=&version=7.16.8&externalPlugins=&assumptions=%7B%7D
---





讲项目不是非常清晰，先概括总结项目是做啥的，然后1、2、3细讲。
职业规划


do good job and good blow job



wiki： 
http://wiki.intra.xiaojukeji.com/pages/viewpage.action?pageId=707402704 
git：
fe: https://git.xiaojukeji.com/global-fe/marketing-group/d-group/d-inkstone 
server: https://git.xiaojukeji.com/global-fe/marketing-group/d-group/d-inkstone-server 
doc: https://git.xiaojukeji.com/global-fe/marketing-group/d-group/d-inkstone-doc
OE：
fe: http://eng.xiaojukeji.com/service/group/109313/repo/61837/overview 
server: http://eng.xiaojukeji.com/service/group/109313/repo/61839/overview 
doc: http://eng.xiaojukeji.com/service/group/109313/repo/61823/overview
地址：
线上： https://d-code.intra.didiglobal.com/#/nocode 
预发： http://d-code-pre.intra.didiglobal.com/#/nocode 
测试：http://10.96.79.63/d-nocode/index.html#/nocode
独立站点：
测试：http://10.190.26.76:9001/d-inkstone
预发【代码未部署】：http://global-inkstone-pre.intra.didiglobal.com
线上【环境未打通】：http://global-inkstone.intra.didiglobal.com
线上的数据库：https://base.xiaojukeji.com/console/rds/?region=ue01#/console
测试数据库：{
  "mysql_pass": "fkAfjK3WX",
  "mysql_port": 4859,
  "db_user": "db_user_eNoG",
  "mysql_user": "didi_aAxq",
  "db_pass": "db_psss_Fy3V",
  "db_port": 3301,
  "mysql_ip": "10.179.45.86",
  "default_db": "user_test"
}



starship代码仓库：
https://git.xiaojukeji.com/global-fe/marketing-group/fleet-platform
OE
http://eng.xiaojukeji.com/service/group/106308/repo/55783/overview
环境
同轨：https://d-server-sim100.intra.xiaojukeji.com/fleet-mis
预发：https://fleet-mis-pre.intra.didiglobal.com/#/home
线上：http://fleet-mis-us.intra.didiglobal.com
文档
http://wiki.intra.xiaojukeji.com/pages/viewpage.action?pageId=801709238
build/webpack.dev.config.ts
  disableHostCheck: true,


Fleet已开国国家梳理
http://wiki.intra.xiaojukeji.com/pages/viewpage.action?pageId=584599448
FMS-FE 各环境部署流程（图文）
http://wiki.intra.xiaojukeji.com/pages/viewpage.action?pageId=589707547


Starship平台支持消息提醒前端方案：http://wiki.intra.xiaojukeji.com/pages/viewpage.action?pageId=837313726
starship 消息push需求：http://wiki.intra.xiaojukeji.com/pages/viewpage.action?pageId=817963986 
Fleet 消息push需求： http://wiki.intra.xiaojukeji.com/pages/viewpage.action?pageId=829429312





/usr/local/etc/nginx



功能投放平台--承接了打车全链路功能的投放

画布和数据设置器的设计，配置化编程的方式，支持后续扩展

设计器最终会生成元数据，元数据包含字段所以信息

通过元数据动态渲染表单，最终得到投放的数据



var str = `balabala![img](https://path.to.img) balabala [text](http://path.to.link) balabala`;
var reg = /\[(.*?)\]\((.*?)\)/ig;
str.replace(reg, `<a href='$2' target='_blank'>$1</a>`);



审核地址在这里：
http://bpm.uetest.intra.didiglobal.com/task/todos?pageSize=10&pageNum=1




北斗PPT 加演示
功能是什么，面向人群，业务产出，template技术实现
1. 接入多少业务（功能点）
2. 功能接入模板（功能接入流程）





业务指标数据需要关注
代码CR、业务内部的人员互相CR

owner职责关注点：
1、和各个项目的PM负责人定期沟通， 稳定的项目1-2月沟通一次，多了解前线 or 大客户对系统的反馈
2、定期与合作方(PM、RD等)沟通，听取他们的反馈
3、关注项目PV、UV等业务指标数据
4、kick off + 需求分工、排期明确
5、了解和指导实习生等同学的技术方案，注重代码质量和体验
6、风险及时同步
7、望岳状态及时同步（已完成需求及时close）
所有人需关注：
1、望岳人力及时更新
2、统一维护个人周报+cooper周会周报
3、项目内部人员之间过CR

1、2 一两个月花个一小时就成；3 每周花个十分钟就成







优化数据收集

TODO: 数据看板 找PM当面聊，希望能用数易现成的功能
https://upm.didiglobal.com/upm2-static/manage/app/list
2200090
2200104










TODO: 
i18n 接入
时区切换 数据


i18n多语言接入文档：
https://cooper.didichuxing.com/docs/document/2199277611164

和数易沟通功能点
1. 数易支持i18n（需数易开发）
2. 数易时区和starship系统时区做联动（数易支持）
3. 数易筛选城市和starship系统国家做联动（数易支持）


langs: ['zh_cn', 'en_us', 'en_au']
await fetch('https://i18n.intra.didiglobal.com/copywriter/listCopyCoreByKeyLang', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    langs:['zh_cn', 'en_us', 'en_au'],
    keys:['Fleet_sms_The_aggregator_AUQX']
  }),
}).then((response) => response.json())





先强调一下，仅供科研学习用，请不要校外传播
    推荐一波自己用的梯子，教育邮箱可以免费一年，个人体验下来，速度和稳定性都相当可以，速度的话Youtube可以流畅4k，稳定性的话，至少在lz使用的这三年里从未掉线过。
操作方法如下：
  1. 进入https://glados.rocks/  （如果登不上，可以进入https://github.com/glados-network/GLaDOS ，点击左下角的“Enter GlaDOS”）
  2. 用bupt邮箱注册账号，验证码可能要等1~2分钟。注册后要求输入邀请码，可以用的邀请码  6E521-UVHBY-IHXE5-ROS5N  （输入后双方都可以获得几天的会员天数）
  3. 页面拉到底，点击左下角的“EducationPlan”（手机端看不到，点这个链接即可https://glados.rocks/console/education/ ），随后点击“Apply”，最后回到“Account/我的账户”，即可看到套餐时间变为1年
  4. Windows、iOS、Android 、MacOS和Linux设备，点击“Home/首页”，选择不同操作系统，按照流程操作即可

旺 快涨   同我的
相 慢涨   生我的
休 横盘   我生的
囚 慢跌   我克的
死 快跌   克我的









https://cstest.didiglobal.com/fe/ticket/ark_fe?lang=zh-CN#/ark/work-bench-list?ticketId=360287970622612169&handle=true
工单处理页面

1. 北斗投放现在投放量最多的是哪些业务线

1. 补偿工具。出行和外卖都由后端下发 前端渲染


https://bpm.didichuxing.com/trace/983aa8ab-273e-11ed-bbfe-08c0eb39ddfc

